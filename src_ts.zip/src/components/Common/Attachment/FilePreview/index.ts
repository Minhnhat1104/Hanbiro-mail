// @ts-nocheck
export { default as FilePreview } from "./FilePreview"
