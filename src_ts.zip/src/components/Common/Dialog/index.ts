// @ts-nocheck
export { default as Dialog } from "./Dialog"
