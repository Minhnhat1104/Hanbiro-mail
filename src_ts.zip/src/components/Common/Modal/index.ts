// @ts-nocheck
export { default as ModalConfirm } from "./ModalConfirm"
export { default as ModalAlert } from "./ModalAlert"
