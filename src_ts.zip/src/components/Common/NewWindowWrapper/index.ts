// @ts-nocheck
import React from "react"

const NewWindowWrapper = props => {
  return <div className="vh-100 p-3 pt-4 bg-white">{props.children}</div>
}

export default NewWindowWrapper
