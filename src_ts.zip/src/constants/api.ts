// @ts-nocheck
export const HAN_API_ERROR_MESSAGE = "han-api-error"
