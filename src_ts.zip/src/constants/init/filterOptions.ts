// @ts-nocheck
export const EMAIL_SORT = "emailsort";
export const SUBJECT_SORT = "subjectsort";
export const SIZE_SORT = "size";
export const DATE_SORT = "date";
