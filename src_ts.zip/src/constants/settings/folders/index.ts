// @ts-nocheck
export const permissionOptions = [
  { label: "mail.mail_no_permission", value: "np" },
  { label: "mail.mail_read_mail", value: "r" },
  { label: "mail.mail_folder_setting_share_setting", value: "w" },
  { label: "mail.mail_reply_forward", value: "s" },
  { label: "mail.mail_read_share", value: "rw" },
  { label: "mail.mail_read_reply_forward", value: "rs" },
  { label: "mail.mail_share_reply_forward", value: "ws" },
  { label: "mail.mail_read_share_forward", value: "rws" },
]