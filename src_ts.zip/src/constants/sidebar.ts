// @ts-nocheck
import { t } from "i18next"

export const menuAll = {
  key: "all",
  title: t("mail.mail_list_search_allbox"),
  parentTitle: "",
}
