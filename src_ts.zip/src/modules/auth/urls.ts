// @ts-nocheck
export const URL_LOGIN_IN = "sign/auth"
export const URL_GET_CONFIG = "common/config/mode/all"
export const URL_POST_PERSONAL_SETTING = "common/setting"
