// @ts-nocheck
export const URL_GET_EMAIL_LIST = "email/list"
export const URL_GET_EMAIL_PREVIEW = "email/preview"
export const URL_PERMIT_MAIL = "email/secu/sent"
export const URL_PERMIT_APPROVER_INFO = "email/secu/managerdetail"
export const URL_PERMIT_MAIL_DETAILS = "email/approval"
export const URL_GET_FOLDER_ADD_CONTACT = "addrbook/contact/folder_add_contact"
export const URL_ADD_TO_CONTACT = "addrbook/contact/add"



